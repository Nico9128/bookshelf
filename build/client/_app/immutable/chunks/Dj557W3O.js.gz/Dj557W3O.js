import{h as s,a as c,b as m,E as h}from"./BndMDAK_.js";import{B as i}from"./Ce27Asz6.js";function E(n,r,o){s&&c();var e=new i(n);m(()=>{var a=r()??null;e.ensure(a,a&&(t=>o(t,a)))},h)}export{E as c};
