import{l as o,d as r}from"../chunks/Cj8uB2Pz.js";export{o as load_css,r as start};
